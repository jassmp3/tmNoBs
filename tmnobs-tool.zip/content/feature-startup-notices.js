// Feature: NO STARTUP NOTICES
// Dismisses informational/agreement-style dialogs that appear on page load
// (e.g. "Welcome, here's what's new", general informational notices).
// Never touches cookie/privacy consent, payment, security, or auth dialogs
// (enforced centrally in dialog-utils.js).

(function () {
  const NS = window.TMnoBS;

  const CONTEXT_HINTS = [
    "welcome", "notice", "important information", "before you continue",
    "please note", "new feature", "update", "heads up", "just so you know",
    "here's what's new", "know before you go", "event info", "good to know",
    "what you need to know", "important info"
  ];

  function run() {
    const matches = NS.dialogUtils.findSafeDismissals(CONTEXT_HINTS);
    matches.forEach(({ button }) => {
      if (button.dataset.tmnobsClicked) return;
      button.dataset.tmnobsClicked = "1";
      button.click();
    });
  }

  NS.features.noStartupNotices = { run };
})();
