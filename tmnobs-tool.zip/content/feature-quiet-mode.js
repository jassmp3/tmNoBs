// Feature: QUIET MODE
// A conservative catch-all that dismisses clearly non-essential
// informational overlays. Relies entirely on the shared safety filter in
// dialog-utils.js, which refuses to touch anything mentioning security,
// auth, CAPTCHA, payment, availability errors, or legal/consent content.

(function () {
  const NS = window.TMnoBS;

  function run(settings) {
    if (!settings.quietMode) return;

    const matches = NS.dialogUtils.findSafeDismissals();
    matches.forEach(({ button }) => {
      if (button.dataset.tmnobsClicked) return;
      button.dataset.tmnobsClicked = "1";
      button.click();
    });
  }

  NS.features.quietMode = { run };
})();
