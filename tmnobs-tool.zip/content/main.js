// TMnoBS main orchestrator
// Reads settings, and re-runs enabled feature modules whenever the page
// changes (via a single shared, debounced MutationObserver) or whenever
// settings change (instantly, via chrome.storage.onChanged).

(function () {
  const NS = window.TMnoBS;
  let currentSettings = null;
  let observer = null;

  const REASONS_ALL = ["resale", "vip", "platinum", "meetgreet", "citi", "aboveprice", "soldout", "tcreminder"];

  function unhideEverything() {
    REASONS_ALL.forEach((r) => NS.tmUnhideByReason(r));
  }

  function runAllFeatures(settings) {
    if (!settings.power) {
      unhideEverything();
      return;
    }

    if (settings.noStartupNotices) NS.features.noStartupNotices.run(settings);
    if (settings.noOfferReminders) NS.features.noOfferReminders.run(settings);
    NS.features.inventoryFilters.run(settings); // internally checks each hide* flag
    NS.features.quantitySelector.run(settings);
    NS.features.tcReminder.run(settings);
    NS.features.accessibilityAgreements.run(settings);
    NS.features.ticketProtection.run(settings);
    NS.features.checkoutPrefs.run(settings);
    NS.features.priceFilter.run(settings);
    NS.features.soldOut.run(settings);
    NS.features.mapView.run(settings);
    NS.features.quietMode.run(settings);
    NS.features.magicSelector.run(settings);
  }

  const debouncedRun = NS.debounce(() => {
    if (currentSettings) runAllFeatures(currentSettings);
  }, 250);

  function startObserving() {
    if (observer) return;
    observer = new MutationObserver((mutations) => {
      // Cheap early-out: ignore mutations that only touch TMnoBS's own
      // bookkeeping attributes, to avoid feedback loops.
      const relevant = mutations.some((m) => {
        if (m.type === "attributes" && m.attributeName && m.attributeName.startsWith("data-tmnobs")) {
          return false;
        }
        return true;
      });
      if (relevant) debouncedRun();
    });
    observer.observe(document.documentElement, {
      childList: true,
      subtree: true,
      attributes: true,
      attributeFilter: ["class", "style", "aria-hidden", "disabled"]
    });
  }

  function stopObserving() {
    if (observer) {
      observer.disconnect();
      observer = null;
    }
  }

  async function init() {
    currentSettings = await NS.getSettings();
    runAllFeatures(currentSettings);

    if (currentSettings.power) startObserving();

    NS.onSettingsChanged((next) => {
      const powerJustChanged = !currentSettings || currentSettings.power !== next.power;
      currentSettings = next;
      runAllFeatures(currentSettings);
      if (currentSettings.power) startObserving();
      else stopObserving();
      void powerJustChanged;
    });

    // SPA navigations (event -> event, page -> checkout) often do not fire
    // a full reload. Re-run features on history changes as a safety net.
    const wrap = (fn) =>
      function () {
        const result = fn.apply(this, arguments);
        debouncedRun();
        return result;
      };
    history.pushState = wrap(history.pushState);
    history.replaceState = wrap(history.replaceState);
    window.addEventListener("popstate", debouncedRun);
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", init);
  } else {
    init();
  }

  // Exposed so the floating panel (panel.js) can apply a settings change
  // to the live page instantly, without waiting on a storage round trip.
  NS.pushSettings = function (next) {
    currentSettings = next;
    runAllFeatures(currentSettings);
    if (currentSettings.power) startObserving();
    else stopObserving();
    NS.saveSettings(next);
  };
  NS.getCurrentSettings = function () {
    return currentSettings;
  };
})();
