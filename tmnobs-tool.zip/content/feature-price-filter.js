// Feature: HIDE ABOVE PRICE
// Visually suppresses ticket rows priced above a user-configured maximum,
// wherever the interface exposes readable price text. Never selects,
// reserves, or purchases tickets based on price - display only.

(function () {
  const NS = window.TMnoBS;
  const REASON = "aboveprice";

  const ROW_SELECTORS = [
    '[data-testid*="listing" i]',
    '[data-testid*="offer" i]',
    '[data-testid*="quickpick" i]',
    '[class*="quick-pick" i]',
    '[class*="listing" i]',
    '[class*="ticket-group" i]',
    '[class*="offer-card" i]',
    '[class*="price-type" i]'
  ];

  function collectRows() {
    const seen = new Set();
    const rows = [];
    ROW_SELECTORS.forEach((sel) => {
      let nodes;
      try {
        nodes = document.querySelectorAll(sel);
      } catch (e) {
        return;
      }
      nodes.forEach((el) => {
        if (!seen.has(el)) {
          seen.add(el);
          rows.push(el);
        }
      });
    });
    return rows;
  }

  function extractHighestPrice(text) {
    const matches = text.match(/[\$£€]\s?(\d{1,5}(?:[.,]\d{2})?)/g);
    if (!matches) return null;
    const values = matches.map((m) => parseFloat(m.replace(/[^\d.]/g, "")));
    return values.length ? Math.max(...values) : null;
  }

  function run(settings) {
    if (!settings.hideAbovePrice || !settings.maxPrice || settings.maxPrice <= 0) {
      NS.tmUnhideByReason(REASON);
      return;
    }

    collectRows().forEach((row) => {
      const text = NS.normText(row);
      if (!text) return;
      const price = extractHighestPrice(text);
      if (price === null) return; // unknown price - never hide on a guess
      if (price > settings.maxPrice) {
        NS.tmHide(row, REASON);
      }
    });
  }

  NS.features.priceFilter = { run };
})();
