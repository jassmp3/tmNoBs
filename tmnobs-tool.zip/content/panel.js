// TMnoBS floating panel
// Renders the entire control panel as a draggable, shadow-DOM-isolated
// overlay directly on the Ticketmaster page (so it can be moved anywhere,
// unlike a browser toolbar popup). Visibility is toggled by clicking the
// extension's toolbar icon (see background/service-worker.js), which
// flips settings.panelOpen; this script just reacts to that.

(function () {
  const NS = window.TMnoBS;
  if (window.__tmnobsPanelLoaded) return;
  window.__tmnobsPanelLoaded = true;

  const FEATURES = [
    { key: "noStartupNotices", name: "NO STARTUP NOTICES", tip: "Automatically handles informational/agreement-style startup dialogs." },
    { key: "noOfferReminders", name: "NO OFFER REMINDERS", tip: "Dismisses offer-info popups. Offer-code ticket inventory always stays visible." },
    { key: "hideVerifiedResale", name: "HIDE VERIFIED RESALE", tip: "Unchecks/hides Verified Resale ticket inventory. Never hides Standard tickets." },
    { key: "hideVip", name: "HIDE VIP", tip: "Unchecks/hides VIP-style ticket packages (detected by wording or the gold star badge)." },
    { key: "hideOfficialPlatinum", name: "HIDE OFFICIAL PLATINUM", tip: "Unchecks/hides Official Platinum inventory." },
    { key: "hideMeetGreet", name: "HIDE MEET & GREET", tip: "Unchecks/hides Meet & Greet inventory." },
    { key: "hideCitiPreferred", name: "HIDE CITI CARDMEMBER PREFERRED", tip: "Unchecks Citi Cardmember Preferred ticket access." },
    { key: "keepOfferTickets", name: "KEEP OFFER TICKETS", tip: "Protects promotional/offer-code bundles (parking packages, fast lane, etc.) from being hidden by the filters above." },
    { key: "hideTcReminder", name: "HIDE T&C REMINDER", tip: "Hides the small, dismissible Terms & Conditions reminder banner near checkout." },
    { key: "skipAccessibilityAgreements", name: "SKIP ACCESSIBILITY AGREEMENTS", tip: "Auto-confirms the standard accessible-seating agreement dialog (checks the agree box, then continues) once identified. Never touches seat selection." },
    { key: "noTicketProtection", name: "DEFAULT: NO TICKET PROTECTION", tip: "Selects your usual decline option for the ticket-insurance upsell, when shown." },
    { key: "rememberCheckoutPreferences", name: "REMEMBER CHECKOUT PREFERENCES", tip: "Restores your usual checkout checkbox choices, and auto-confirms the standard \"I understand my selection\" acknowledgment. Never submits your order." },
    { key: "rememberFilters", name: "REMEMBER FILTERS", tip: "Your filter choices persist automatically and reapply across events and tabs." },
    { key: "hideAbovePrice", name: "HIDE ABOVE PRICE", tip: "Hides tickets priced above the maximum you set. Display only.", hasInput: true },
    { key: "hideSoldOut", name: "HIDE SOLD-OUT", tip: "Hides clearly sold-out or unavailable ticket inventory." },
    { key: "rememberMapView", name: "REMEMBER MAP VIEW", tip: "Experimental: attempts to preserve your seat map zoom and position." },
    { key: "quietMode", name: "QUIET MODE", tip: "A conservative mode that suppresses only clearly non-essential overlays." },
    { key: "magicSelector", name: "MAGIC SELECTOR", tip: "PREMIUM - Experimental. Hold left-click and drag a line across available seats to toggle-select them - drag over an already-selected seat again to deselect it. Never touches the Reserve/purchase step.", premium: true }
  ];

  /* ---------------- Smooth (non-pixel) knife icon, emoji-style ---------------- */
  function buildKnifeSvg() {
    return (
      '<svg viewBox="0 0 64 26" preserveAspectRatio="xMidYMid meet">' +
      '<defs>' +
      '<linearGradient id="tmnobsBlade" x1="0" y1="0" x2="1" y2="1">' +
      '<stop offset="0%" stop-color="#f5fdff"/>' +
      '<stop offset="35%" stop-color="#cdeef5"/>' +
      '<stop offset="60%" stop-color="#8fb9c4"/>' +
      '<stop offset="100%" stop-color="#e3f7fb"/>' +
      '</linearGradient>' +
      '<linearGradient id="tmnobsHandle" x1="0" y1="0" x2="0" y2="1">' +
      '<stop offset="0%" stop-color="#3c3c3c"/>' +
      '<stop offset="50%" stop-color="#161616"/>' +
      '<stop offset="100%" stop-color="#3c3c3c"/>' +
      "</linearGradient>" +
      "</defs>" +
      '<path d="M43,4 L9,10.5 Q2,13 9,15.5 L43,22 Z" fill="url(#tmnobsBlade)" stroke="#3a5560" stroke-width="0.6"/>' +
      '<rect x="41" y="6" width="4" height="14" fill="#cfd6d9"/>' +
      '<rect x="44" y="7" width="17" height="12" rx="3.5" fill="url(#tmnobsHandle)"/>' +
      '<circle cx="53" cy="13" r="1.3" fill="#5a5a5a"/>' +
      "</svg>"
    );
  }

  const PANEL_CSS = [
    ":host, .tmnobs-root { all: initial; }",
    ".tmnobs-root { font-family: 'Segoe UI', -apple-system, BlinkMacSystemFont, Roboto, sans-serif; color: #dfe9ec; width: 320px; border-radius: 18px; overflow: hidden; box-shadow: 0 12px 34px rgba(0,0,0,0.55), 0 0 0 1px rgba(90,220,255,0.14); position: relative; user-select: none; display: block; }",

    ".bg-layer { position: absolute; inset: 0; z-index: 0; overflow: hidden; background: #26292c; transition: background 0.5s ease; }",
    ".bg-layer.power-on { background: #0a1f2e; }",
    ".blob { position: absolute; width: 170px; height: 170px; border-radius: 50%; filter: blur(30px); opacity: 0; animation-play-state: paused; }",
    ".bg-layer.power-on .blob { opacity: 0.55; animation-play-state: running; transition: opacity 0.6s ease; }",
    ".blob1 { background: #1e6fa8; top: -30px; left: -20px; animation: driftA 14s ease-in-out infinite; }",
    ".blob2 { background: #2b3f9e; bottom: -40px; right: -30px; animation: driftB 18s ease-in-out infinite; }",
    ".blob3 { background: #14a3c7; top: 40%; left: 40%; animation: driftC 22s ease-in-out infinite; }",
    "@keyframes driftA { 0%,100% { transform: translate(0,0); } 50% { transform: translate(70px, 50px); } }",
    "@keyframes driftB { 0%,100% { transform: translate(0,0); } 50% { transform: translate(-60px, -35px); } }",
    "@keyframes driftC { 0%,100% { transform: translate(0,0) scale(1); } 50% { transform: translate(-35px, 25px) scale(1.15); } }",

    ".content { position: relative; z-index: 1; user-select: none; transition: opacity 0.4s ease; }",
    ".content.content-hidden { opacity: 0; }",

    ".startup-overlay { position: absolute; inset: 0; z-index: 50; display: none; align-items: center; justify-content: center; flex-direction: column; gap: 8px; border-radius: 18px; background: radial-gradient(ellipse at 50% 30%, rgba(90,220,255,0.14), transparent 60%), linear-gradient(180deg,#030405,#06080a 60%,#020304); opacity: 1; }",
    ".startup-overlay.anim-out { opacity: 0; transition: opacity 0.4s ease; }",
    ".startup-knife-wrap { width: 84px; perspective: 400px; opacity: 0; }",
    ".startup-overlay.anim-play .startup-knife-wrap { animation: startupKnifeIn 1s cubic-bezier(.4,.1,.2,1) forwards; }",
    "@keyframes startupKnifeIn { 0% { opacity: 0; transform: rotateY(0deg) scale(0.5); } 20% { opacity: 1; } 100% { opacity: 1; transform: rotateY(720deg) scale(1); } }",
    ".startup-title { font-size: 30px; font-weight: 800; opacity: 0; }",
    ".startup-overlay.anim-play .startup-title { animation: fadeUp 0.5s ease 1.05s forwards; }",
    ".startup-byline { font-size: 12px; letter-spacing: 3px; font-weight: 700; color: #e8eef0; opacity: 0; }",
    ".startup-overlay.anim-play .startup-byline { animation: fadeUp 0.4s ease 1.35s forwards; }",
    ".startup-tagline { font-size: 10.5px; letter-spacing: 2.4px; color: #5adcff; opacity: 0; }",
    ".startup-overlay.anim-play .startup-tagline { animation: fadeUp 0.4s ease 1.6s forwards; }",
    "@keyframes fadeUp { from { opacity: 0; transform: translateY(4px); } to { opacity: 1; transform: translateY(0); } }",

    ".drag-handle { display: flex; align-items: center; gap: 10px; padding: 11px 12px; cursor: grab; background: rgba(0,0,0,0.18); border-bottom: 1px solid rgba(90,220,255,0.14); }",
    ".drag-handle:active { cursor: grabbing; }",
    ".knife-icon { width: 30px; height: auto; filter: drop-shadow(0 0 4px rgba(90,220,255,0.5)); animation: knifeIdle 6s linear infinite; flex-shrink: 0; display: inline-block; }",
    ".knife-icon svg { width: 30px; display: block; }",
    "@keyframes knifeIdle { from { transform: rotateY(0deg); } to { transform: rotateY(360deg); } }",
    ".title-wrap { flex: 1; line-height: 1.25; }",
    ".title { font-size: 16px; font-weight: 800; }",
    ".t-tm { font-style: italic; color: #5adcff; }",
    ".t-no { color: #fff; margin: 0 1px; }",
    ".t-bs { color: #ffd400; font-weight: 900; }",
    ".byline { font-size: 8.5px; letter-spacing: 1.8px; font-weight: 700; color: #cfeaf2; }",
    ".tagline { font-size: 7.5px; letter-spacing: 1.6px; color: #8a9aa1; }",
    ".clock { font-family: 'Consolas', 'SFMono-Regular', monospace; font-size: 10px; letter-spacing: 0.5px; color: #7fe3ff; background: rgba(90,220,255,0.08); border: 1px solid rgba(90,220,255,0.22); border-radius: 6px; padding: 3px 6px; text-shadow: 0 0 5px rgba(90,220,255,0.6); white-space: nowrap; }",
    ".close-btn { background: none; border: none; color: #7c8890; font-size: 15px; cursor: pointer; width: 22px; height: 22px; border-radius: 5px; line-height: 1; }",
    ".close-btn:hover { background: rgba(255,255,255,0.08); color: #fff; }",

    ".power-row { display: flex; align-items: center; gap: 12px; padding: 13px 14px; }",
    ".power-btn { width: 56px; height: 56px; border-radius: 50%; border: none; cursor: pointer; flex-shrink: 0; background: radial-gradient(circle at 32% 28%, #eef1f2 0%, #c6cbce 22%, #8f959a 55%, #4c5155 100%); box-shadow: inset 0 1px 2px rgba(255,255,255,0.8), inset 0 -3px 5px rgba(0,0,0,0.4), 0 2px 6px rgba(0,0,0,0.5); display: flex; align-items: center; justify-content: center; position: relative; transition: box-shadow 0.35s ease; }",
    ".power-btn:active { transform: scale(0.95); }",
    ".power-ring { position: absolute; inset: -6px; border-radius: 50%; border: 3px solid rgba(255,212,0,0.12); transition: border-color 0.35s ease, box-shadow 0.35s ease; }",
    ".power-btn[data-on='true'] .power-ring { border-color: #ffe14d; box-shadow: 0 0 3px 1px rgba(255,225,77,0.95) inset, 0 0 14px 3px rgba(255,212,0,0.85), 0 0 30px 9px rgba(255,196,0,0.5); }",
    ".power-btn[data-on='true'] { box-shadow: inset 0 1px 2px rgba(255,255,255,0.85), inset 0 -3px 5px rgba(0,0,0,0.4), 0 2px 6px rgba(0,0,0,0.5), 0 0 24px 6px rgba(255,196,0,0.45); }",
    ".power-btn svg { width: 30px; height: 30px; transition: color 0.35s ease, filter 0.35s ease; }",
    ".power-btn[data-on='true'] svg { color: #ffe14d; filter: drop-shadow(0 0 5px rgba(255,225,77,0.95)) drop-shadow(0 0 10px rgba(255,196,0,0.5)); }",
    ".power-btn[data-on='false'] svg { color: #4a4f53; }",
    ".power-text { font-size: 12px; letter-spacing: 1.4px; color: #8a9aa1; }",
    ".power-text.on { color: #ffd400; }",

    ".mem-line { margin: 0 14px 10px; padding: 6px 10px; border-radius: 9px; background: rgba(255,255,255,0.04); border: 1px solid rgba(90,220,255,0.12); font-size: 10px; color: #93a3aa; display: flex; align-items: center; justify-content: space-between; gap: 6px; }",
    ".mem-line b { color: #cfeaf2; font-weight: 700; }",
    ".mem-refresh { background: none; border: none; color: #5adcff; cursor: pointer; font-size: 11px; padding: 0 2px; }",

    ".feature-list { max-height: 280px; overflow-y: auto; padding: 0 12px; }",
    ".feature-list::-webkit-scrollbar { width: 5px; }",
    ".feature-list::-webkit-scrollbar-thumb { background: #2a3237; border-radius: 3px; }",
    ".feature-row { display: flex; align-items: center; gap: 8px; padding: 7px 1px; border-bottom: 1px solid rgba(255,255,255,0.04); position: relative; }",
    ".feature-row:last-child { border-bottom: none; }",
    ".feature-dot { width: 7px; height: 7px; border-radius: 50%; background: #2a3237; flex-shrink: 0; }",
    ".feature-row[data-on='true'] .feature-dot { background: #ffd400; box-shadow: 0 0 5px rgba(255,212,0,0.8); }",
    ".feature-name-wrap { position: relative; flex: 1; min-width: 0; }",
    ".feature-name { font-size: 11.5px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; display: block; }",
    ".feature-name.premium { color: #ffd400; }",
    ".feature-tooltip { position: absolute; left: 0; top: 100%; margin-top: 4px; width: 220px; z-index: 30; background: #0d1418; border: 1px solid rgba(90,220,255,0.16); color: #9aa8ae; font-size: 10px; line-height: 1.4; padding: 8px 9px; border-radius: 7px; opacity: 0; pointer-events: none; transition: opacity 0.12s ease; }",
    ".feature-name-wrap:hover .feature-tooltip { opacity: 1; }",
    ".tm-toggle { position: relative; width: 34px; height: 18px; border-radius: 11px; border: none; background: #1c2226; cursor: pointer; flex-shrink: 0; }",
    ".tm-toggle::after { content:''; position:absolute; top:2px; left:2px; width:14px; height:14px; border-radius:50%; background:#7c8890; transition: transform 0.12s ease, background 0.12s ease; }",
    ".tm-toggle[data-checked='true'] { background: rgba(255,212,0,0.18); box-shadow: inset 0 0 0 1px #8a7300; }",
    ".tm-toggle[data-checked='true']::after { transform: translateX(16px); background: #ffd400; box-shadow: 0 0 5px rgba(255,212,0,0.7); }",
    ".price-input { width: 50px; background:#10161a; border:1px solid rgba(90,220,255,0.16); border-radius:5px; color:#dfe9ec; font-size:10.5px; padding:2px 5px; margin-right: 4px; }",
    ".feature-list.disabled { opacity: 0.35; filter: grayscale(0.4); pointer-events: none; }",

    ".qty-block { margin: 10px 14px; padding: 9px 12px; border-radius: 10px; background: rgba(255,255,255,0.04); border: 1px solid rgba(90,220,255,0.12); display: flex; align-items: center; justify-content: space-between; }",
    ".qty-block.disabled { opacity: 0.35; pointer-events: none; }",
    ".qty-label { font-size: 10px; letter-spacing: 1.2px; color: #8a9aa1; }",
    ".qty-selector { perspective: 200px; width: 44px; height: 34px; border-radius: 8px; border: 1px solid rgba(90,220,255,0.16); background: linear-gradient(180deg,#232a2f,#14181b); cursor: pointer; display: flex; align-items: center; justify-content: center; }",
    ".qty-face { font-size: 15px; font-weight: 800; color: #ffd400; }",
    ".qty-face.rolling { animation: qtyRoll 0.25s ease; }",
    "@keyframes qtyRoll { 0% { transform: rotateX(0deg); } 50% { transform: rotateX(90deg); opacity:0.2; } 100% { transform: rotateX(0deg); } }",

    ".footer { padding: 10px 14px 12px; border-top: 1px solid rgba(90,220,255,0.1); text-align: center; }",
    ".footer-note { font-size: 7.4px; line-height: 1.45; color: #566268; margin: 0 0 6px; }",
    ".premium-tag { font-size: 9px; letter-spacing: 1.4px; color: #8a7300; }"
  ].join("\n");

  function panelHtml() {
    const rows = FEATURES.map(function (f) {
      const inputHtml = f.hasInput
        ? '<input class="price-input" type="number" min="0" placeholder="$max" data-price-for="' + f.key + '" />'
        : "";
      return (
        '<div class="feature-row" data-key="' + f.key + '" data-on="false">' +
        '<span class="feature-dot"></span>' +
        '<div class="feature-name-wrap">' +
        '<span class="feature-name' + (f.premium ? " premium" : "") + '">' + f.name + "</span>" +
        '<div class="feature-tooltip">' + f.tip + "</div>" +
        "</div>" +
        inputHtml +
        '<button class="tm-toggle" data-toggle="' + f.key + '" data-checked="false" aria-label="' + f.name + '"></button>' +
        "</div>"
      );
    }).join("");

    return (
      '<div class="tmnobs-root">' +
      '<div class="bg-layer" id="bgLayer">' +
      '<div class="blob blob1"></div><div class="blob blob2"></div><div class="blob blob3"></div>' +
      "</div>" +

      '<div class="startup-overlay" id="startupOverlay">' +
      '<div class="startup-knife-wrap">' + buildKnifeSvg() + "</div>" +
      '<div class="startup-title"><span class="t-tm">tm</span><span class="t-no">no</span><span class="t-bs">BS</span></div>' +
      '<div class="startup-byline">BY JASS</div>' +
      '<div class="startup-tagline">BE A FOCUS FOX</div>' +
      "</div>" +

      '<div class="content" id="contentEl">' +
      '<div class="drag-handle" id="dragHandle">' +
      '<span class="knife-icon">' + buildKnifeSvg() + "</span>" +
      '<div class="title-wrap">' +
      '<div class="title"><span class="t-tm">tm</span><span class="t-no">no</span><span class="t-bs">BS</span></div>' +
      '<div class="byline">BY JASS</div>' +
      '<div class="tagline">BE A FOCUS FOX</div>' +
      "</div>" +
      '<span class="clock" id="clockText">--:-- --</span>' +
      '<button class="close-btn" id="closeBtn" aria-label="Close panel">&#10005;</button>' +
      "</div>" +
      '<div class="power-row">' +
      '<button class="power-btn" id="powerBtn" data-on="false" aria-label="Toggle TMnoBS">' +
      '<span class="power-ring"></span>' +
      '<svg viewBox="0 0 24 24"><path d="M12 2v9" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" fill="none"/><path d="M6.5 5.8a8 8 0 1 0 11 0" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" fill="none"/></svg>' +
      "</button>" +
      '<span class="power-text" id="powerText">TMnoBS is OFF</span>' +
      "</div>" +
      '<div class="mem-line"><span id="memText">&mdash; open a Ticketmaster tab</span><button class="mem-refresh" id="memRefresh" title="Refresh">&#8635;</button></div>' +
      '<div class="feature-list disabled" id="featureList">' + rows + "</div>" +
      '<div class="qty-block disabled" id="qtyBlock">' +
      '<span class="qty-label">NUMBER OF TICKETS</span>' +
      '<button class="qty-selector" id="qtySelector"><span class="qty-face" id="qtyFace">2</span></button>' +
      "</div>" +
      '<div class="footer">' +
      '<p class="footer-note">TMnoBS customizes the interface based on your preferences. It never bypasses security, CAPTCHA, queues, authentication, or payment systems, and never submits your final purchase.</p>' +
      '<div class="premium-tag">&#10022; More control. Less BS. &#10022;</div>' +
      "</div>" +
      "</div>" +
      "</div>"
    );
  }

  let shadow = null;
  let host = null;
  let settings = null;
  let wasVisible = false;

  function clamp(v, min, max) { return Math.max(min, Math.min(max, v)); }

  function setPanelPosition(x, y) {
    host.style.left = clamp(x, 0, window.innerWidth - 120) + "px";
    host.style.top = clamp(y, 0, window.innerHeight - 60) + "px";
    host.style.right = "";
  }

  function wireDragging() {
    const handle = shadow.getElementById("dragHandle");
    let dragging = false;
    let startX = 0, startY = 0, originX = 0, originY = 0;

    handle.addEventListener("mousedown", function (e) {
      if (e.target.closest("#closeBtn")) return;
      dragging = true;
      startX = e.clientX;
      startY = e.clientY;
      const rect = host.getBoundingClientRect();
      originX = rect.left;
      originY = rect.top;
      e.preventDefault();
    });

    window.addEventListener("mousemove", function (e) {
      if (!dragging) return;
      setPanelPosition(originX + (e.clientX - startX), originY + (e.clientY - startY));
    });

    window.addEventListener("mouseup", function () {
      if (!dragging) return;
      dragging = false;
      const rect = host.getBoundingClientRect();
      const base = NS.getCurrentSettings() || settings;
      const next = Object.assign({}, base, { panelX: rect.left, panelY: rect.top });
      NS.saveSettings(next);
    });
  }

  function updateRowVisual(key, value) {
    const row = shadow.querySelector('.feature-row[data-key="' + key + '"]');
    if (!row) return;
    row.dataset.on = String(!!value);
    const toggle = row.querySelector(".tm-toggle");
    if (toggle) toggle.dataset.checked = String(!!value);
  }

  function triggerStartupAnimation() {
    const overlay = shadow.getElementById("startupOverlay");
    const contentEl = shadow.getElementById("contentEl");
    overlay.style.display = "flex";
    overlay.classList.remove("anim-out", "anim-play");
    contentEl.classList.add("content-hidden");
    void overlay.offsetWidth; // restart animation every time this runs
    overlay.classList.add("anim-play");

    setTimeout(function () {
      overlay.classList.add("anim-out");
      contentEl.classList.remove("content-hidden");
    }, 2000);
    setTimeout(function () {
      overlay.style.display = "none";
    }, 2450);
  }

  function renderAll(next) {
    settings = next;

    const powerBtn = shadow.getElementById("powerBtn");
    const powerText = shadow.getElementById("powerText");
    const bgLayer = shadow.getElementById("bgLayer");
    powerBtn.dataset.on = String(!!settings.power);
    powerText.textContent = settings.power ? "TMnoBS is ON" : "TMnoBS is OFF";
    powerText.classList.toggle("on", !!settings.power);
    bgLayer.classList.toggle("power-on", !!settings.power);

    shadow.getElementById("featureList").classList.toggle("disabled", !settings.power);
    shadow.getElementById("qtyBlock").classList.toggle("disabled", !settings.power);

    FEATURES.forEach(function (f) { updateRowVisual(f.key, settings[f.key]); });

    const priceInput = shadow.querySelector('[data-price-for="hideAbovePrice"]');
    if (priceInput && shadow.activeElement !== priceInput) {
      priceInput.value = settings.maxPrice || "";
    }

    shadow.getElementById("qtyFace").textContent = String(settings.ticketQuantity);

    const willBeVisible = !!settings.panelOpen;
    host.style.display = willBeVisible ? "block" : "none";
    if (!wasVisible && willBeVisible) {
      triggerStartupAnimation();
    }
    wasVisible = willBeVisible;

    if (settings.panelX != null && settings.panelY != null) {
      setPanelPosition(settings.panelX, settings.panelY);
    }
  }

  function applyAndPersist(mutator) {
    const base = NS.getCurrentSettings() || settings;
    const next = Object.assign({}, base);
    mutator(next);
    renderAll(next);
    NS.pushSettings(next); // applies to the live page immediately + persists
  }

  function wireControls() {
    shadow.getElementById("closeBtn").addEventListener("click", function () {
      applyAndPersist(function (n) { n.panelOpen = false; });
    });

    shadow.getElementById("powerBtn").addEventListener("click", function () {
      applyAndPersist(function (n) { n.power = !n.power; });
    });

    FEATURES.forEach(function (f) {
      const toggle = shadow.querySelector('[data-toggle="' + f.key + '"]');
      toggle.addEventListener("click", function () {
        const cur = NS.getCurrentSettings() || settings;
        if (!cur.power) return;
        const key = f.key;
        applyAndPersist(function (n) { n[key] = !n[key]; });
      });
    });

    const priceInput = shadow.querySelector('[data-price-for="hideAbovePrice"]');
    if (priceInput) {
      priceInput.addEventListener("change", function () {
        applyAndPersist(function (n) { n.maxPrice = Number(priceInput.value) || 0; });
      });
    }

    const qtyBtn = shadow.getElementById("qtySelector");
    const qtyFace = shadow.getElementById("qtyFace");
    const sequence = [1, 2, 3, "4+"];
    qtyBtn.addEventListener("click", function () {
      const current = (NS.getCurrentSettings() || settings).ticketQuantity;
      const idx = sequence.indexOf(current);
      const nextVal = sequence[(idx + 1 + sequence.length) % sequence.length];
      applyAndPersist(function (n) { n.ticketQuantity = nextVal; });
      qtyFace.classList.remove("rolling");
      void qtyFace.offsetWidth;
      qtyFace.classList.add("rolling");
    });

    shadow.getElementById("memRefresh").addEventListener("click", refreshMemory);
  }

  function formatMB(mb) {
    if (mb >= 1024) return "~" + (mb / 1024).toFixed(2) + " GB";
    return "~" + Math.round(mb) + " MB";
  }

  function refreshMemory() {
    const el = shadow.getElementById("memText");
    if (!NS.getMemorySnapshot) {
      el.textContent = "estimate unavailable";
      return;
    }
    const d = NS.getMemorySnapshot();
    el.innerHTML = "<b>" + formatMB(d.estimateMB) + "</b> est. &middot; " + d.intensity + " load";
  }

  function updateClock() {
    const el = shadow.getElementById("clockText");
    if (!el) return;
    try {
      const formatted = new Intl.DateTimeFormat("en-US", {
        timeZone: "America/New_York",
        hour: "2-digit",
        minute: "2-digit",
        hour12: true,
        timeZoneName: "short"
      }).format(new Date());
      el.textContent = formatted;
    } catch (e) {
      el.textContent = "--:-- --";
    }
  }

  function init() {
    host = document.createElement("div");
    host.id = "tmnobs-panel-host";
    host.style.position = "fixed";
    host.style.top = "80px";
    host.style.right = "20px";
    host.style.zIndex = "2147483647";
    host.style.display = "none";
    document.documentElement.appendChild(host);

    shadow = host.attachShadow({ mode: "open" });
    const styleEl = document.createElement("style");
    styleEl.textContent = PANEL_CSS;
    shadow.appendChild(styleEl);
    const wrapper = document.createElement("div");
    wrapper.innerHTML = panelHtml();
    shadow.appendChild(wrapper.firstElementChild);

    wireDragging();
    wireControls();
    updateClock();
    setInterval(updateClock, 30000);

    NS.getSettings().then(function (s) {
      renderAll(s);
      refreshMemory();
    });

    NS.onSettingsChanged(function (next) {
      renderAll(next);
    });

    setInterval(function () {
      if (host.style.display !== "none") refreshMemory();
    }, 4000);
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", init);
  } else {
    init();
  }
})();
