// Feature: REMEMBER MAP VIEW (experimental)
// Best-effort preservation of seat-map zoom/pan. Ticketmaster's map is
// often canvas/SVG-based with no stable public API, so this only acts
// when a CSS-transformed map wrapper can be confidently identified, and
// fails gracefully (does nothing) otherwise - it never breaks the map.

(function () {
  const NS = window.TMnoBS;

  function findMapWrapper() {
    const candidates = document.querySelectorAll(
      '[class*="seat-map" i], [class*="seatmap" i], [id*="seatmap" i], [data-testid*="map" i]'
    );
    for (const el of candidates) {
      if (!NS.isVisible(el)) continue;
      // Look for the actual element carrying the pan/zoom transform,
      // which is usually a direct child wrapping an <svg> or <canvas>.
      const transformed = el.querySelector('[style*="transform"]') || el;
      if (transformed.querySelector("svg, canvas")) return transformed;
    }
    return null;
  }

  function eventKey() {
    // Use the path (minus querystring) as a stable-enough per-event key.
    return `tmnobsMapView:${location.pathname}`;
  }

  async function saveView(transformValue) {
    const key = eventKey();
    await chrome.storage.local.set({ [key]: transformValue });
  }

  async function restoreView(wrapper) {
    const key = eventKey();
    const data = await chrome.storage.local.get(key);
    const saved = data[key];
    if (!saved) return;
    try {
      wrapper.style.transform = saved;
    } catch (e) {
      // Fail silently - never break the map.
    }
  }

  function attachObserver(wrapper) {
    if (wrapper.dataset.tmnobsMapObserved) return;
    wrapper.dataset.tmnobsMapObserved = "1";
    const debouncedSave = NS.debounce(() => {
      const t = wrapper.style.transform;
      if (t) saveView(t);
    }, 500);
    const mo = new MutationObserver(debouncedSave);
    mo.observe(wrapper, { attributes: true, attributeFilter: ["style"] });
  }

  async function run(settings) {
    if (!settings.rememberMapView) return;
    const wrapper = findMapWrapper();
    if (!wrapper) return; // graceful no-op if the map can't be identified

    if (!wrapper.dataset.tmnobsMapRestored) {
      wrapper.dataset.tmnobsMapRestored = "1";
      await restoreView(wrapper);
    }
    attachObserver(wrapper);
  }

  NS.features.mapView = { run };
})();
