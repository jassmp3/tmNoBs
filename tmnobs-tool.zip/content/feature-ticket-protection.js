// Feature: DEFAULT - NO TICKET PROTECTION
// When a ticket-insurance/"keep my tickets safe" upsell is presented,
// selects the user's normal decline option. Never submits anything and
// never acts if Ticketmaster presents an unfamiliar structure.

(function () {
  const NS = window.TMnoBS;

  const SECTION_HINTS = [
    "keep my tickets safe", "ticket insurance", "protect your tickets",
    "ticket protection", "purchase protection"
  ];

  const DECLINE_LABELS = [
    "no thanks", "no, thanks", "no thank you", "decline", "no protection",
    "don't protect my tickets", "do not protect my tickets", "skip protection",
    "no, i don't need this", "remove protection", "no"
  ];

  function findProtectionSections() {
    const all = document.querySelectorAll('div, section, fieldset');
    const out = [];
    all.forEach((el) => {
      if (!NS.isVisible(el)) return;
      const text = NS.normText(el);
      if (!text) return;
      if (text.length > 1200) return; // avoid matching huge parent containers
      if (SECTION_HINTS.some((h) => text.includes(h))) out.push(el);
    });
    // Keep only the smallest (most specific) matching containers.
    return out.filter((el) => !out.some((other) => other !== el && el.contains(other)));
  }

  function findDeclineControl(section) {
    const options = Array.from(
      section.querySelectorAll('input[type="radio"], input[type="checkbox"], button, [role="radio"]')
    );
    for (const opt of options) {
      const label =
        NS.normText(opt) ||
        NS.normText(opt.closest("label")) ||
        NS.normText(document.querySelector(`label[for="${opt.id}"]`));
      if (!label) continue;
      if (DECLINE_LABELS.includes(label)) return opt;
    }
    return null;
  }

  function run(settings) {
    if (!settings.noTicketProtection) return;

    findProtectionSections().forEach((section) => {
      if (section.dataset.tmnobsProtectionHandled) return;
      const control = findDeclineControl(section);
      if (!control) return; // unfamiliar structure - do nothing
      if (control.tagName === "INPUT" && !control.checked) {
        control.click();
      } else if (control.tagName !== "INPUT") {
        control.click();
      }
      section.dataset.tmnobsProtectionHandled = "1";
    });
  }

  NS.features.ticketProtection = { run };
})();
