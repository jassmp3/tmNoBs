// Feature: SKIP ACCESSIBILITY AGREEMENTS
// Only ever touches a confirmation/agreement dialog that can be confidently
// identified as being about accessible-seating eligibility (by explicit
// wording). Never selects, filters, or otherwise manipulates accessible
// seating inventory itself - the user already made that choice by picking
// an accessible ticket type; this just clears the standard confirmation
// step for them instead of leaving it sitting on screen.
//
// Ticketmaster's real dialog is a two-step control: an "I agree" checkbox
// that must be checked before a "Continue" button becomes clickable. Both
// steps are handled here, and the dialog is re-checked on every DOM
// mutation (not locked after one click) so the now-enabled Continue button
// gets clicked as soon as it becomes available.

(function () {
  const NS = window.TMnoBS;

  const CONTEXT_HINTS = [
    "accessible seating", "accessibility", "wheelchair", "ada seating",
    "accessible ticket", "companion seat"
  ];

  function isDisabled(el) {
    if (!el) return true;
    if (el.disabled) return true;
    if (el.getAttribute("aria-disabled") === "true") return true;
    if (el.classList && el.classList.contains("disabled")) return true;
    return false;
  }

  function findAgreeCheckbox(dialog) {
    return dialog.querySelector('input[type="checkbox"]');
  }

  function findContinueButton(dialog) {
    const candidates = dialog.querySelectorAll('button, [role="button"]');
    for (const btn of candidates) {
      const label = NS.normText(btn);
      if (["continue", "ok", "agree", "agree & continue", "agree and continue", "done"].includes(label)) {
        return btn;
      }
    }
    return null;
  }

  function run(settings) {
    if (!settings.skipAccessibilityAgreements) return;

    const dialogs = NS.dialogUtils.findCandidateDialogs();
    dialogs.forEach((dialog) => {
      const text = NS.normText(dialog);
      if (!text || !CONTEXT_HINTS.some((h) => text.includes(h))) return;
      if (NS.dialogUtils.CRITICAL_KEYWORDS.some((k) => text.includes(k))) return; // extra safety, belt & braces

      const checkbox = findAgreeCheckbox(dialog);
      if (checkbox && !checkbox.checked) {
        checkbox.click();
      }

      const continueBtn = findContinueButton(dialog);
      if (continueBtn && !isDisabled(continueBtn)) {
        continueBtn.click();
      }
    });
  }

  NS.features.accessibilityAgreements = { run };
})();
