// Feature: REMEMBER CHECKOUT PREFERENCES
// Learns the user's own manual choices on repeatable checkout checkboxes
// (e.g. "email me event updates") and restores them on future checkouts.
// Never touches legal agreement checkboxes (terms/privacy), and never
// clicks a final purchase/place order/submit payment button.

(function () {
  const NS = window.TMnoBS;

  const EXCLUDED_LABEL_PATTERNS = [
    "terms", "privacy", "i agree to", "agree to the terms", "conditions of sale"
  ];

  const FINAL_ACTION_PATTERNS = [
    "purchase", "place order", "buy now", "submit payment", "complete order", "pay now", "confirm purchase"
  ];

  // A well-known, low-stakes Ticketmaster checkbox that sits right before
  // checkout ("I understand my ticket/seat selection..."). It's a routine
  // acknowledgment, not a legal terms/privacy agreement, so it's treated
  // like the other default checkout conveniences (e.g. No Ticket
  // Protection) and checked by default the first time it's seen, rather
  // than only after the user has manually taught it once.
  const DEFAULT_CHECK_PATTERNS = [
    ["understand", "selection"],
    ["understand", "seat"],
    ["understand", "ticket"]
  ];

  function matchesDefaultCheckPattern(label) {
    return DEFAULT_CHECK_PATTERNS.some((words) => words.every((w) => label.includes(w)));
  }

  function isFinalActionElement(el) {
    return FINAL_ACTION_PATTERNS.some((p) => NS.normText(el).includes(p));
  }

  function labelFor(checkbox) {
    const ariaLabel = checkbox.getAttribute("aria-label");
    if (ariaLabel) return ariaLabel.toLowerCase().trim();
    if (checkbox.id) {
      const l = document.querySelector(`label[for="${checkbox.id}"]`);
      if (l) return NS.normText(l);
    }
    const parentLabel = checkbox.closest("label");
    if (parentLabel) return NS.normText(parentLabel);
    // Fallback for custom-styled checkboxes where the visible text is a
    // sibling element rather than a semantic <label> - without this, any
    // checkbox built this way is silently skipped entirely.
    const container = checkbox.closest("div, li, section") || checkbox.parentElement;
    if (container) {
      const text = NS.normText(container);
      if (text && text.length < 220) return text;
    }
    return "";
  }

  function isEligible(checkbox, label) {
    if (!label) return false;
    if (EXCLUDED_LABEL_PATTERNS.some((p) => label.includes(p))) return false;
    if (isFinalActionElement(checkbox)) return false;
    return true;
  }

  async function getStore() {
    const data = await chrome.storage.local.get("tmnobsCheckoutPrefs");
    return data.tmnobsCheckoutPrefs || {};
  }

  async function saveChoice(label, checked) {
    const store = await getStore();
    store[label] = checked;
    await chrome.storage.local.set({ tmnobsCheckoutPrefs: store });
  }

  function attachLearningListener(checkbox, label) {
    if (checkbox.dataset.tmnobsLearning) return;
    checkbox.dataset.tmnobsLearning = "1";
    checkbox.addEventListener("change", () => {
      saveChoice(label, checkbox.checked);
    });
  }

  async function run(settings) {
    if (!settings.rememberCheckoutPreferences) return;

    const checkboxes = document.querySelectorAll('input[type="checkbox"]');
    if (!checkboxes.length) return;
    const store = await getStore();

    checkboxes.forEach((checkbox) => {
      if (!NS.isVisible(checkbox)) return;
      const label = labelFor(checkbox);
      if (!isEligible(checkbox, label)) return;

      attachLearningListener(checkbox, label);

      if (matchesDefaultCheckPattern(label) && !checkbox.checked && checkbox.dataset.tmnobsAutoChecked !== "1") {
        checkbox.click();
        checkbox.dataset.tmnobsAutoChecked = "1";
      }

      if (Object.prototype.hasOwnProperty.call(store, label) && checkbox.dataset.tmnobsRestored !== label) {
        const desired = store[label];
        if (checkbox.checked !== desired) {
          checkbox.click();
        }
        checkbox.dataset.tmnobsRestored = label;
      }
    });
  }

  NS.features.checkoutPrefs = { run };
})();
