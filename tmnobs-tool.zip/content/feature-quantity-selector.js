// Feature: NUMBER OF TICKETS
// Attempts to set Ticketmaster's own quantity control to match the
// user's configured preference (1 / 2 / 3 / 4+). Verifies the underlying
// control's value actually changed rather than only updating appearance.
// If no confidently-identified quantity control exists, does nothing.

(function () {
  const NS = window.TMnoBS;

  function findQuantitySelect() {
    const selectors = [
      'select[id*="quantity" i]',
      'select[name*="quantity" i]',
      'select[aria-label*="quantity" i]',
      '[data-testid*="quantity" i] select'
    ];
    for (const sel of selectors) {
      const el = document.querySelector(sel);
      if (el && NS.isVisible(el)) return el;
    }
    return null;
  }

  function findQuantityStepper() {
    // Common "stepper" pattern: a container with +/- buttons and a
    // numeric readout, labeled with the word "quantity".
    const containers = document.querySelectorAll('[data-testid*="quantity" i], [class*="quantity" i], [aria-label*="quantity" i]');
    for (const container of containers) {
      if (!NS.isVisible(container)) continue;
      const buttons = container.querySelectorAll('button');
      if (buttons.length >= 2) return container;
    }
    return null;
  }

  // Sets a native <select>'s value in a way that frameworks like React
  // will actually observe (bypassing the instance value setter).
  function setSelectValue(select, desiredText) {
    const options = Array.from(select.options);
    let target = options.find((o) => o.textContent.trim() === desiredText);
    if (!target && desiredText === "4+") {
      // Fall back to the highest numeric option available.
      target = options.reduce((best, o) => {
        const n = parseInt(o.textContent, 10);
        if (Number.isNaN(n)) return best;
        return !best || n > parseInt(best.textContent, 10) ? o : best;
      }, null);
    }
    if (!target) return false;

    const nativeSetter = Object.getOwnPropertyDescriptor(window.HTMLSelectElement.prototype, "value").set;
    nativeSetter.call(select, target.value);
    select.dispatchEvent(new Event("input", { bubbles: true }));
    select.dispatchEvent(new Event("change", { bubbles: true }));
    return select.value === target.value;
  }

  function readStepperValue(container) {
    const text = NS.normText(container);
    const match = text.match(/\b([1-9]\d?)\b/);
    return match ? parseInt(match[1], 10) : null;
  }

  function nudgeStepper(container, desiredNumber) {
    const buttons = Array.from(container.querySelectorAll("button"));
    const plus = buttons.find((b) => /\+|increase|add/i.test(b.textContent + (b.getAttribute("aria-label") || "")));
    const minus = buttons.find((b) => /-|decrease|remove/i.test(b.textContent + (b.getAttribute("aria-label") || "")));
    if (!plus) return;

    let current = readStepperValue(container);
    if (current === null) return;
    let guard = 0;
    while (current !== null && current < desiredNumber && guard < 10) {
      plus.click();
      guard += 1;
      current = readStepperValue(container);
    }
    while (minus && current !== null && current > desiredNumber && guard < 10) {
      minus.click();
      guard += 1;
      current = readStepperValue(container);
    }
  }

  function run(settings) {
    const desired = settings.ticketQuantity; // 1 | 2 | 3 | "4+"
    const desiredText = String(desired);
    const desiredNumber = desired === "4+" ? 4 : Number(desired);

    const select = findQuantitySelect();
    if (select) {
      const key = `applied-${desiredText}`;
      if (select.dataset.tmnobsQty === key) return;
      const ok = setSelectValue(select, desiredText);
      if (ok) select.dataset.tmnobsQty = key;
      return;
    }

    const stepper = findQuantityStepper();
    if (stepper) {
      const key = `applied-${desiredNumber}`;
      if (stepper.dataset.tmnobsQty === key) return;
      nudgeStepper(stepper, desiredNumber);
      stepper.dataset.tmnobsQty = key;
      return;
    }

    // No confidently-identified quantity control on this page - do nothing.
  }

  NS.features.quantitySelector = { run };
})();
