// Features: HIDE VERIFIED RESALE / HIDE VIP / HIDE OFFICIAL PLATINUM /
// HIDE MEET & GREET / HIDE CITI CARDMEMBER PREFERRED / KEEP OFFER TICKETS
//
// Two Ticketmaster UI patterns are handled:
//
// 1. The "Filters" panel's Ticket Type checkbox list. Here TMnoBS UNCHECKS
//    the matching checkbox (Ticketmaster's own filter then hides the type
//    from results) rather than deleting anything from the page - the row
//    stays visible and unchecked, exactly like a normal manual filter
//    change, and is fully reversible by re-checking it.
//
// 2. The simpler "quick pick" listing view, where categories are grouped
//    under a short heading like "VIP Packages" with no checkboxes. Here
//    TMnoBS hides only rows whose OWN short text matches a category
//    keyword - "Standard" tickets are always explicitly protected and are
//    never hidden or unchecked, regardless of any other signal.

(function () {
  const NS = window.TMnoBS;

  const CATEGORY_TEXT = {
    hideVerifiedResale: ["verified resale", "resale"],
    hideVip: ["vip package", "vip experience", "vip ticket", " vip "],
    hideOfficialPlatinum: ["official platinum", "platinum"],
    hideMeetGreet: ["meet & greet", "meet and greet", "m&g"],
    hideCitiPreferred: ["citi", "cardmember preferred"]
  };

  // Protected no matter what - never hidden, never unchecked.
  const PROTECT_ALWAYS = ["standard", "accessible"];

  // Promotional/bundle wording that should stay checked/visible even if
  // "Keep Offer Tickets" is the only thing standing between it and a
  // same-worded restricted category.
  const PROTECT_PATTERNS = [
    "summer pack", "2-ticket offer", "2 ticket offer", "4-ticket offer",
    "4 ticket offer", "ticket offer", "offer code", "promo code",
    "promotional offer", "artist presale offer", "fan offer",
    "package", "parking space", "chair rental", "fast lane", "quick entry"
  ];

  function containsAny(text, words) {
    return words.some((w) => text.includes(w));
  }

  function hasGoldStarIcon(row) {
    return !!row.querySelector(
      'svg[class*="star" i], [class*="star" i], svg[aria-label*="star" i], [aria-label*="premium" i]'
    );
  }

  function hasLockIcon(row) {
    return !!row.querySelector('svg[class*="lock" i], [class*="lock" i]');
  }

  // Ticketmaster puts a padlock icon on more than one kind of row - Citi
  // Cardmember Preferred tickets, but also unrelated locked/exclusive
  // promotional offers (e.g. "Labor Day Offer"). A bare lock icon isn't
  // enough signal on its own; require accompanying "member"/"citi" wording
  // so an unrelated locked offer never gets swept in by this fallback.
  function looksLikeCitiRow(row, rowText) {
    if (rowText.includes("citi") || rowText.includes("member")) return true;
    return !!row.querySelector('[class*="citi" i], img[alt*="citi" i], [aria-label*="citi" i]');
  }

  /* ---------- Pattern 1: native "Ticket Type" filter checkboxes ---------- */

  function findTicketTypeHeading() {
    const candidates = document.querySelectorAll(
      'legend, h1, h2, h3, h4, h5, h6, [class*="heading" i], [class*="title" i], span, div'
    );
    for (const el of candidates) {
      const text = NS.normText(el);
      if (text === "ticket type" && el.children.length === 0) return el;
    }
    return null;
  }

  function isDisabled(el) {
    if (!el) return true;
    if (el.disabled) return true;
    if (el.getAttribute("aria-disabled") === "true") return true;
    if (el.classList && el.classList.contains("disabled")) return true;
    return false;
  }

  // The Ticket Type checkbox list doesn't live-filter as you click - it
  // stages your changes until you press this button. TMnoBS has to press
  // it too, or an unchecked box just sits there unapplied until the person
  // happens to reopen the panel.
  function findApplyFiltersButton(fromEl) {
    let scope = fromEl;
    for (let i = 0; i < 6 && scope; i++) {
      const candidates = scope.querySelectorAll('button, [role="button"]');
      for (const btn of candidates) {
        const label = NS.normText(btn);
        if (label === "apply filters" || label === "apply") return btn;
      }
      scope = scope.parentElement;
    }
    return null;
  }

  function findCheckboxRows() {
    const heading = findTicketTypeHeading();
    if (!heading) return [];
    // The checkbox list sits in a shared ancestor a few levels up.
    let container = heading.parentElement;
    for (let i = 0; i < 4 && container; i++) {
      if (container.querySelectorAll('input[type="checkbox"]').length >= 2) break;
      container = container.parentElement;
    }
    if (!container) return [];

    const checkboxes = Array.from(container.querySelectorAll('input[type="checkbox"]'));
    return checkboxes
      .map((cb) => {
        // Walk up to the smallest ancestor that reads as one full row.
        let row = cb.closest("label") || cb.parentElement;
        for (let i = 0; i < 3 && row && row.parentElement && NS.normText(row).length < 3; i++) {
          row = row.parentElement;
        }
        return { checkbox: cb, row: row || cb };
      })
      .filter((r) => NS.isVisible(r.checkbox));
  }

  function desiredCheckedState(rowText, row, settings) {
    if (PROTECT_ALWAYS.some((p) => rowText.includes(p))) return true; // never uncheck
    const isProtectedOffer = settings.keepOfferTickets && containsAny(rowText, PROTECT_PATTERNS);
    if (isProtectedOffer) return true;

    for (const [settingKey, words] of Object.entries(CATEGORY_TEXT)) {
      if (!settings[settingKey]) continue;
      if (containsAny(rowText, words)) return false;
    }
    if (settings.hideVip && hasGoldStarIcon(row) && !isProtectedOffer) return false;
    if (settings.hideOfficialPlatinum && hasGoldStarIcon(row) && !isProtectedOffer) return false;
    if (settings.hideCitiPreferred && hasLockIcon(row) && looksLikeCitiRow(row, rowText) && !isProtectedOffer) return false;

    return true; // default: leave as-is / visible
  }

  function runCheckboxFilters(settings) {
    const rows = findCheckboxRows();
    if (!rows.length) return false;

    let changedAny = false;
    rows.forEach(({ checkbox, row }) => {
      const text = NS.normText(row);
      if (!text) return;
      const desired = desiredCheckedState(text, row, settings);
      if (checkbox.checked !== desired) {
        checkbox.click(); // real interaction -> Ticketmaster's own filter state updates
        changedAny = true;
      }
    });

    if (changedAny) {
      const applyBtn = findApplyFiltersButton(rows[0].row);
      if (applyBtn && !isDisabled(applyBtn)) applyBtn.click();
    }

    return true;
  }

  /* ---------- Pattern 2: quick-pick grouped list (fallback) ---------- */

  const ROW_SELECTORS = [
    '[data-testid*="listing" i]',
    '[data-testid*="offer" i]',
    '[data-testid*="quickpick" i]',
    '[class*="quick-pick" i]',
    '[class*="listing" i]',
    '[class*="ticket-group" i]',
    '[class*="offer-card" i]',
    '[class*="price-type" i]'
  ];

  function collectQuickPickRows() {
    const seen = new Set();
    const rows = [];
    ROW_SELECTORS.forEach((sel) => {
      let nodes;
      try {
        nodes = document.querySelectorAll(sel);
      } catch (e) {
        return;
      }
      nodes.forEach((el) => {
        if (!seen.has(el)) {
          seen.add(el);
          rows.push(el);
        }
      });
    });
    return rows;
  }

  const REASON_MAP = {
    hideVerifiedResale: "resale",
    hideVip: "vip",
    hideOfficialPlatinum: "platinum",
    hideMeetGreet: "meetgreet",
    hideCitiPreferred: "citi"
  };

  function runQuickPickRows(settings) {
    const anyHideActive = Object.keys(REASON_MAP).some((k) => settings[k]);

    Object.entries(REASON_MAP).forEach(([settingKey, reason]) => {
      if (!settings[settingKey]) NS.tmUnhideByReason(reason);
    });
    if (!anyHideActive) return;

    collectQuickPickRows().forEach((row) => {
      const text = NS.normText(row);
      if (!text) return;
      if (PROTECT_ALWAYS.some((p) => text.includes(p))) return; // "standard" etc. never hidden
      if (settings.keepOfferTickets && containsAny(text, PROTECT_PATTERNS)) return;

      for (const [settingKey, words] of Object.entries(CATEGORY_TEXT)) {
        if (!settings[settingKey]) continue;
        if (containsAny(text, words)) {
          NS.tmHide(row, REASON_MAP[settingKey]);
          return;
        }
      }
    });
  }

  function run(settings) {
    const handledByCheckboxes = runCheckboxFilters(settings);
    // Always also run the fallback pass - the quick-pick view and the
    // filter-panel view can appear side by side depending on the page.
    runQuickPickRows(settings);
    void handledByCheckboxes;
  }

  NS.features.inventoryFilters = { run };
})();
