// Feature: MAGIC SELECTOR (experimental, premium)
// While this is on, holding the left mouse button down anywhere on the
// seat map and dragging draws a rectangular selection box (like selecting
// icons on a desktop). Every available seat whose position falls inside
// that box gets toggled once - selected if it wasn't, deselected if it
// already was. This only ever runs while a human is actively holding the
// mouse button and moving it; it never selects anything on its own, and
// it never touches the Reserve/purchase step.
//
// Why a rectangle instead of a "pen line": checking a live rectangle
// against a list of seat positions captured once at drag-start is
// completely immune to fast mouse movement (a thin line sampled between
// mousemove events can skip seats a fast drag jumps over; a growing box
// re-evaluates every seat's position on every move, so nothing is missed
// regardless of drag speed).
//
// Why both pointer AND mouse events are intercepted: modern interactive
// map libraries are built on either event family depending on how they
// were written, and a page's own pan/zoom handler only gets suppressed if
// we block the SAME event type it's actually listening to. Blocking only
// mouse events left pointer-event-based maps free to keep panning
// underneath us, which is what made earlier attempts silently do nothing.
// Listeners are attached on `window` itself (the earliest possible point
// in the capture phase) so our interception always runs before the map's
// own handlers get a chance to see the event.
//
// Ticketmaster's map is sometimes canvas-rendered with no individual DOM
// node per seat, in which case this feature cannot detect seats and does
// nothing (fails gracefully, same philosophy as Remember Map View).

(function () {
  const NS = window.TMnoBS;

  let enabled = false;
  let dragging = false;
  let originX = 0;
  let originY = 0;
  let seatCandidates = []; // [{el, rect}] captured once per drag stroke
  let touchedThisStroke = new Set();
  let marqueeEl = null;

  /* ---------------- seat detection (color-agnostic) ---------------- */

  function isSeatShaped(el) {
    if (!el || el.nodeType !== 1) return false;
    const tag = el.tagName.toLowerCase();
    const rect = el.getBoundingClientRect();
    if (rect.width < 5 || rect.width > 90) return false;
    if (rect.height < 5 || rect.height > 90) return false;
    if (tag === "circle") return true;
    let cs;
    try {
      cs = window.getComputedStyle(el);
    } catch (e) {
      return false;
    }
    const br = cs.borderRadius;
    if (!br) return false;
    const minSide = Math.min(rect.width, rect.height);
    const radiusPx = parseFloat(br);
    return br.includes("50%") || (!Number.isNaN(radiusPx) && radiusPx >= minSide / 2 - 2);
  }

  // Selection is color-agnostic on purpose - every hue a venue map uses
  // (standard blue, "legendary" tiers, resale, VIP, whatever) is fair
  // game. Only a structural signal that a seat isn't purchasable
  // (sold/unavailable/disabled class or id) disqualifies it - never color.
  function isBlocked(el) {
    let node = el;
    for (let i = 0; i < 3 && node; i++) {
      const cls = ((node.getAttribute && node.getAttribute("class")) || "").toLowerCase();
      const idAttr = (node.id || "").toLowerCase();
      const blocked = ["disabled", "sold", "unavailable", "not-available", "inactive"];
      if (blocked.some((b) => cls.includes(b) || idAttr.includes(b))) return true;
      node = node.parentElement;
    }
    return false;
  }

  function isInsideOwnPanel(el) {
    return !!(el && el.closest && el.closest("#tmnobs-panel-host"));
  }

  // One-time (per drag-stroke) scan of the whole page for seat-shaped,
  // selectable elements. Cheap enough to do once at mousedown; doing this
  // instead of repeated elementFromPoint() calls during the drag is what
  // makes the rectangle immune to fast mouse movement.
  function collectSeatCandidates() {
    const out = [];
    const all = document.querySelectorAll(
      'circle, [class*="seat" i], [data-testid*="seat" i], div, span, a, button'
    );
    for (const el of all) {
      if (isInsideOwnPanel(el)) continue;
      if (!NS.isVisible(el)) continue;
      if (!isSeatShaped(el)) continue;
      if (isBlocked(el)) continue;
      out.push({ el, rect: el.getBoundingClientRect() });
    }
    return out;
  }

  function rectsIntersect(a, b) {
    return !(b.left > a.right || b.right < a.left || b.top > a.bottom || b.bottom < a.top);
  }

  function simulateSeatClick(el) {
    const rect = el.getBoundingClientRect();
    const x = rect.left + rect.width / 2;
    const y = rect.top + rect.height / 2;
    ["pointerdown", "mousedown", "pointerup", "mouseup", "click"].forEach((type) => {
      el.dispatchEvent(new MouseEvent(type, { bubbles: true, cancelable: true, clientX: x, clientY: y, view: window }));
    });
  }

  /* ---------------- visual marquee box ---------------- */

  function ensureMarqueeEl() {
    if (marqueeEl) return marqueeEl;
    marqueeEl = document.createElement("div");
    marqueeEl.id = "tmnobs-marquee";
    Object.assign(marqueeEl.style, {
      position: "fixed",
      border: "1.5px solid #5adcff",
      background: "rgba(90,220,255,0.15)",
      zIndex: "2147483647",
      pointerEvents: "none",
      borderRadius: "2px",
      display: "none"
    });
    document.documentElement.appendChild(marqueeEl);
    return marqueeEl;
  }

  function updateMarqueeVisual(x1, y1, x2, y2) {
    const el = ensureMarqueeEl();
    const left = Math.min(x1, x2);
    const top = Math.min(y1, y2);
    el.style.left = left + "px";
    el.style.top = top + "px";
    el.style.width = Math.abs(x2 - x1) + "px";
    el.style.height = Math.abs(y2 - y1) + "px";
    el.style.display = "block";
  }

  function hideMarqueeVisual() {
    if (marqueeEl) marqueeEl.style.display = "none";
  }

  /* ---------------- drag lifecycle ---------------- */

  function applySelectionBox(x1, y1, x2, y2) {
    const box = {
      left: Math.min(x1, x2),
      right: Math.max(x1, x2),
      top: Math.min(y1, y2),
      bottom: Math.max(y1, y2)
    };
    seatCandidates.forEach(({ el, rect }) => {
      if (touchedThisStroke.has(el)) return;
      if (!rectsIntersect(box, rect)) return;
      touchedThisStroke.add(el);
      simulateSeatClick(el);
    });
  }

  function beginDrag(x, y) {
    dragging = true;
    originX = x;
    originY = y;
    touchedThisStroke = new Set();
    seatCandidates = collectSeatCandidates();
    updateMarqueeVisual(x, y, x, y);
  }

  function endDrag() {
    dragging = false;
    seatCandidates = [];
    touchedThisStroke = new Set();
    hideMarqueeVisual();
  }

  function shouldEngage(target, x, y) {
    if (isInsideOwnPanel(target)) return false;
    // Direct hit on a seat is the strongest signal.
    let node = target;
    for (let i = 0; i < 3 && node; i++) {
      if (isSeatShaped(node)) return true;
      node = node.parentElement;
    }
    // Otherwise, only engage if the page actually has a cluster of seats
    // somewhere near this point (covers starting in a gap between seats).
    const nearby = document.elementsFromPoint ? document.elementsFromPoint(x, y) : [];
    return nearby.some((el) => !isInsideOwnPanel(el) && isSeatShaped(el));
  }

  /* ---------------- unified pointer + mouse interception ---------------- */
  // Attached on `window` (earliest possible point) with capture:true so we
  // always see the event before the page's own pan/zoom handlers do,
  // whichever event family (pointer or legacy mouse) they listen to.

  function handleDown(e) {
    if (!enabled || e.button !== 0) return;
    if (!shouldEngage(e.target, e.clientX, e.clientY)) return;

    beginDrag(e.clientX, e.clientY);
    applySelectionBox(originX, originY, e.clientX, e.clientY);

    e.preventDefault();
    e.stopPropagation();
    if (e.stopImmediatePropagation) e.stopImmediatePropagation();
  }

  function handleMove(e) {
    if (!enabled || !dragging) return;
    updateMarqueeVisual(originX, originY, e.clientX, e.clientY);
    applySelectionBox(originX, originY, e.clientX, e.clientY);

    e.preventDefault();
    e.stopPropagation();
    if (e.stopImmediatePropagation) e.stopImmediatePropagation();
  }

  function handleUp(e) {
    if (!dragging) return;
    endDrag();
    if (e) {
      e.preventDefault();
      e.stopPropagation();
      if (e.stopImmediatePropagation) e.stopImmediatePropagation();
    }
  }

  let attached = false;
  function attachListeners() {
    if (attached) return;
    attached = true;

    ["pointerdown", "mousedown"].forEach((type) => window.addEventListener(type, handleDown, true));
    ["pointermove", "mousemove"].forEach((type) => window.addEventListener(type, handleMove, true));
    ["pointerup", "mouseup"].forEach((type) => window.addEventListener(type, handleUp, true));
    // Some libraries cancel a drag on pointer/mouse leaving the window.
    window.addEventListener("blur", () => handleUp(null), true);
    // Prevent native browser drag/ghost-image behavior from hijacking the gesture.
    window.addEventListener(
      "dragstart",
      (e) => {
        if (enabled && dragging) e.preventDefault();
      },
      true
    );
  }

  function run(settings) {
    enabled = !!settings.magicSelector;
    attachListeners();
    if (!enabled && dragging) endDrag();
  }

  NS.features.magicSelector = { run };
})();
