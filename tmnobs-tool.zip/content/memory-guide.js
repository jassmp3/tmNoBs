// MEMORY GUIDE
// A lightweight, clearly-labeled ESTIMATE of this tab's resource load.
// Chrome does not expose true per-tab RAM usage to extensions, so this
// combines the JS heap size (Chrome-only, non-standard performance.memory
// API) with the page's own baseline overhead - it intentionally avoids the
// inflated multipliers that used to make this read wildly too high. It is
// an indicator only and never drives any feature's behavior.

(function () {
  const NS = window.TMnoBS;

  function computeSnapshot() {
    const perfMemory = performance.memory || null;
    const domNodeCount = document.getElementsByTagName("*").length;
    const imageCount = document.images ? document.images.length : 0;
    const hasSeatMap = !!document.querySelector(
      '[class*="seat-map" i], [class*="seatmap" i], canvas, svg[class*="map" i]'
    );

    // A typical browser tab process has on the order of tens of MB of
    // fixed overhead even when nearly idle - we use a modest baseline
    // rather than multiplying the JS heap, which produced unrealistic
    // multi-GB numbers.
    const baselineMB = 45;
    const heapMB = perfMemory ? perfMemory.usedJSHeapSize / (1024 * 1024) : 25;
    const domMB = domNodeCount * 0.01; // ~10KB per live DOM node, rough
    const imageMB = imageCount * 0.35; // ~350KB per decoded image, rough
    const seatMapMB = hasSeatMap ? 30 : 0;

    const estimateMB = baselineMB + heapMB + domMB + imageMB + seatMapMB;

    let intensity = "Light";
    if (estimateMB > 500) intensity = "Heavy";
    else if (estimateMB > 220) intensity = "Moderate";

    return {
      estimateMB,
      domNodeCount,
      imageCount,
      hasSeatMap,
      intensity
    };
  }

  NS.getMemorySnapshot = computeSnapshot;
})();
