// TMnoBS content core
// Shared namespace, storage access, and DOM utilities used by every
// feature module. Feature modules attach themselves to window.TMnoBS.features
// so they can be updated independently without touching this file.

(function () {
  if (window.__tmnobsCoreLoaded) return;
  window.__tmnobsCoreLoaded = true;

  const DEFAULT_SETTINGS = {
    power: false,
    panelOpen: false,
    panelX: null,
    panelY: null,
    noStartupNotices: false,
    noOfferReminders: false,
    hideVerifiedResale: false,
    hideVip: false,
    hideOfficialPlatinum: false,
    hideMeetGreet: false,
    hideCitiPreferred: false,
    keepOfferTickets: true,
    ticketQuantity: 2,
    hideTcReminder: false,
    skipAccessibilityAgreements: false,
    noTicketProtection: false,
    rememberCheckoutPreferences: false,
    rememberFilters: false,
    hideAbovePrice: false,
    maxPrice: 0,
    hideSoldOut: false,
    rememberMapView: false,
    quietMode: false,
    magicSelector: false
  };

  function debounce(fn, wait) {
    let t = null;
    return function debounced(...args) {
      clearTimeout(t);
      t = setTimeout(() => fn.apply(this, args), wait);
    };
  }

  function throttle(fn, wait) {
    let last = 0;
    let pending = null;
    return function throttled(...args) {
      const now = Date.now();
      const remaining = wait - (now - last);
      if (remaining <= 0) {
        last = now;
        fn.apply(this, args);
      } else {
        clearTimeout(pending);
        pending = setTimeout(() => {
          last = Date.now();
          fn.apply(this, args);
        }, remaining);
      }
    };
  }

  // Case-insensitive, whitespace-normalized text match helper.
  function normText(el) {
    return (el && el.textContent ? el.textContent : "").replace(/\s+/g, " ").trim().toLowerCase();
  }

  function isVisible(el) {
    if (!el) return false;
    const rect = el.getBoundingClientRect();
    if (rect.width === 0 && rect.height === 0) return false;
    const style = window.getComputedStyle(el);
    return style.visibility !== "hidden" && style.display !== "none" && parseFloat(style.opacity || "1") > 0;
  }

  // Marks an element as hidden by TMnoBS (rather than deleting it), so
  // features can be toggled back on instantly without a page reload.
  function tmHide(el, reason) {
    if (!el || el.dataset.tmnobsHidden === "1") return;
    el.dataset.tmnobsHidden = "1";
    el.dataset.tmnobsReason = reason || "";
    el.dataset.tmnobsPrevDisplay = el.style.display || "";
    el.style.setProperty("display", "none", "important");
  }

  function tmUnhideByReason(reason) {
    const els = document.querySelectorAll(`[data-tmnobs-reason="${reason}"]`);
    els.forEach((el) => {
      el.style.display = el.dataset.tmnobsPrevDisplay || "";
      delete el.dataset.tmnobsHidden;
      delete el.dataset.tmnobsReason;
      delete el.dataset.tmnobsPrevDisplay;
    });
  }

  async function getSettings() {
    const stored = await chrome.storage.local.get("tmnobsSettings");
    return { ...DEFAULT_SETTINGS, ...(stored.tmnobsSettings || {}) };
  }

  async function saveSettings(next) {
    await chrome.storage.local.set({ tmnobsSettings: next });
  }

  function onSettingsChanged(callback) {
    chrome.storage.onChanged.addListener((changes, area) => {
      if (area !== "local" || !changes.tmnobsSettings) return;
      const next = { ...DEFAULT_SETTINGS, ...(changes.tmnobsSettings.newValue || {}) };
      callback(next);
    });
  }

  window.TMnoBS = {
    DEFAULT_SETTINGS,
    debounce,
    throttle,
    normText,
    isVisible,
    tmHide,
    tmUnhideByReason,
    getSettings,
    saveSettings,
    onSettingsChanged,
    features: {} // populated by feature-*.js files
  };
})();
