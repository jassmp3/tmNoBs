// Feature: HIDE T&C REMINDER
// Hides the small, dismissible Terms & Conditions reminder banner that
// appears near ticket selection/cart. Never touches required legal
// checkout text (identified by the presence of a required checkbox/
// agreement input, which this feature explicitly leaves alone).

(function () {
  const NS = window.TMnoBS;

  const REASON = "tcreminder";

  function looksLikeReminderBanner(el) {
    const text = NS.normText(el);
    if (!text.includes("terms") ) return false;
    if (text.length > 400) return false; // real legal text blocks are long

    const rect = el.getBoundingClientRect();
    if (rect.height > 220) return false; // reminder banners are compact

    // Never touch anything that itself contains a required checkbox -
    // that's a legal agreement control, not a dismissible reminder.
    if (el.querySelector('input[type="checkbox"][required], input[type="checkbox"]')) return false;

    return true;
  }

  function findReminderBanners() {
    const selectors = [
      '[class*="toast" i]',
      '[class*="banner" i]',
      '[class*="notification" i]',
      '[role="status"]',
      '[role="alert"]',
      '[class*="reminder" i]'
    ];
    const seen = new Set();
    const out = [];
    selectors.forEach((sel) => {
      let nodes;
      try {
        nodes = document.querySelectorAll(sel);
      } catch (e) {
        return;
      }
      nodes.forEach((el) => {
        if (seen.has(el) || !NS.isVisible(el)) return;
        seen.add(el);
        if (looksLikeReminderBanner(el)) out.push(el);
      });
    });
    return out;
  }

  function run(settings) {
    if (!settings.hideTcReminder) {
      NS.tmUnhideByReason(REASON);
      return;
    }
    findReminderBanners().forEach((el) => NS.tmHide(el, REASON));
  }

  NS.features.tcReminder = { run };
})();
