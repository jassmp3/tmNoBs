// Feature: NO OFFER REMINDERS
// Dismisses event-specific promotional/offer-INFORMATION dialogs
// (e.g. a popup explaining an offer code exists). Does NOT touch the
// actual offer ticket inventory list - that stays untouched/visible.

(function () {
  const NS = window.TMnoBS;

  const CONTEXT_HINTS = [
    "offer", "promo", "promotion", "presale", "special access",
    "code applied", "discount available", "exclusive access"
  ];

  function run() {
    const matches = NS.dialogUtils.findSafeDismissals(CONTEXT_HINTS);
    matches.forEach(({ dialog, button }) => {
      // Extra guard: never act on something that looks like an inventory
      // list (many ticket rows / prices) rather than a small info dialog.
      const priceLike = dialog.querySelectorAll('[class*="price" i]').length;
      if (priceLike > 3) return;
      if (button.dataset.tmnobsClicked) return;
      button.dataset.tmnobsClicked = "1";
      button.click();
    });
  }

  NS.features.noOfferReminders = { run };
})();
