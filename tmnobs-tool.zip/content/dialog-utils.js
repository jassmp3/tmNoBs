// TMnoBS dialog utilities
// Shared, conservative logic for finding and safely dismissing
// non-critical informational/agreement dialogs on Ticketmaster.
//
// Safety rule: if a dialog's text contains ANY critical keyword
// (payment, security, CAPTCHA, authentication, purchase failure, etc.)
// it is NEVER touched, regardless of which button wording matches.

(function () {
  const NS = window.TMnoBS;
  if (!NS || NS.dialogUtils) return;

  // Keywords that make a dialog off-limits no matter what.
  const CRITICAL_KEYWORDS = [
    "captcha", "verify you are human", "queue", "you're in line", "in line for",
    "payment", "card was declined", "card declined", "billing", "cvv",
    "security", "suspicious activity", "unusual activity",
    "authentic", "sign in", "log in", "password", "two-factor", "2fa",
    "session has expired", "session expired", "expired session",
    "purchase failed", "order failed", "transaction failed", "could not be completed",
    "sold out", "no longer available", "unavailable",
    "error processing", "something went wrong", "declined",
    "fraud", "blocked", "access denied", "forbidden", "rate limit",
    "please wait", "bot detection", "are you a robot", "unusual traffic",
    // Privacy/consent mechanisms are never auto-dismissed by TMnoBS.
    "cookie", "gdpr", "consent", "privacy settings", "manage preferences",
    "do not sell", "ccpa"
  ];

  // Wording treated as a "safe to dismiss" affirmative/close action.
  const DISMISS_WORDS = [
    "ok", "okay", "continue", "agree", "agree & continue", "agree and continue",
    "continue & agree", "continue and agree", "got it", "done", "close",
    "accept", "i understand", "i agree", "dismiss", "no thanks", "not now"
  ];

  function textMatchesAny(text, list) {
    return list.some((kw) => text.includes(kw));
  }

  // Heuristically identify elements that look like an overlay/modal dialog.
  // Two passes are combined because Ticketmaster (and similar SPAs) often
  // use build-hashed class names that don't contain words like "modal" -
  // pass 2 catches those by looking at computed layout instead of class names.
  function findCandidateDialogs() {
    const seen = new Set();
    const out = [];

    // Pass 1: class/attribute based (fast, cheap, catches the common case).
    const selectors = [
      '[role="dialog"]',
      '[role="alertdialog"]',
      '[aria-modal="true"]',
      '[class*="modal" i]',
      '[class*="dialog" i]',
      '[class*="overlay" i]',
      '[id*="modal" i]',
      '[data-testid*="modal" i]',
      '[data-testid*="dialog" i]'
    ];
    selectors.forEach((sel) => {
      let nodes;
      try {
        nodes = document.querySelectorAll(sel);
      } catch (e) {
        return;
      }
      nodes.forEach((el) => {
        if (seen.has(el) || !NS.isVisible(el)) return;
        const rect = el.getBoundingClientRect();
        if (rect.width < 120 || rect.height < 60) return;
        seen.add(el);
        out.push(el);
      });
    });

    // Pass 2: layout based fallback. Portaled dialogs are almost always
    // rendered as a fixed/absolutely positioned element near the top of
    // <body>, regardless of what its classes are named. Scoped to shallow
    // depth so this stays cheap even on a heavy page.
    const shallow = [];
    document.body.querySelectorAll(":scope > *, :scope > * > *").forEach((el) => shallow.push(el));
    shallow.forEach((el) => {
      if (seen.has(el) || !NS.isVisible(el)) return;
      let cs;
      try {
        cs = window.getComputedStyle(el);
      } catch (e) {
        return;
      }
      if (cs.position !== "fixed" && cs.position !== "absolute") return;
      const z = parseInt(cs.zIndex, 10);
      if (Number.isNaN(z) || z < 5) return;
      const rect = el.getBoundingClientRect();
      // A real modal box: sits within the viewport, not covering the
      // whole page edge-to-edge (that would be a backdrop, not the dialog
      // itself) and large enough to hold a heading + text + button.
      if (rect.width < 180 || rect.width > window.innerWidth * 0.95) return;
      if (rect.height < 100 || rect.height > window.innerHeight * 0.95) return;
      if (!el.querySelector("button, [role='button'], a")) return;
      seen.add(el);
      out.push(el);
    });

    return out;
  }

  function findButtonsIn(dialog) {
    return Array.from(dialog.querySelectorAll('button, [role="button"], a[href="#"], input[type="button"], input[type="submit"]'));
  }

  /**
   * Look for currently-open dialogs that are safe, non-critical, and whose
   * text loosely matches `mustIncludeAny` (if provided), then return the
   * best dismiss button for each. Never returns anything for a dialog
   * containing a critical keyword.
   *
   * @param {string[]} [mustIncludeAny] optional extra confidence keywords;
   *        if provided, the dialog text must contain at least one of them.
   * @returns {{dialog: Element, button: Element}[]}
   */
  function findSafeDismissals(mustIncludeAny) {
    const results = [];
    const dialogs = findCandidateDialogs();

    dialogs.forEach((dialog) => {
      const text = NS.normText(dialog);
      if (!text) return;
      if (textMatchesAny(text, CRITICAL_KEYWORDS)) return;
      if (mustIncludeAny && mustIncludeAny.length && !textMatchesAny(text, mustIncludeAny)) return;

      const buttons = findButtonsIn(dialog);
      if (!buttons.length) return;

      // Prefer the button whose own label is a known dismiss word AND is not
      // also flagged as a critical action (e.g. "Continue to Payment").
      let best = null;
      for (const btn of buttons) {
        const label = NS.normText(btn);
        if (!label) continue;
        if (textMatchesAny(label, CRITICAL_KEYWORDS)) continue;
        if (DISMISS_WORDS.includes(label) || DISMISS_WORDS.some((w) => label === w)) {
          best = btn;
          break;
        }
      }
      if (best) results.push({ dialog, button: best });
    });

    return results;
  }

  NS.dialogUtils = {
    CRITICAL_KEYWORDS,
    DISMISS_WORDS,
    findCandidateDialogs,
    findSafeDismissals
  };
})();
