// Feature: HIDE SOLD-OUT
// Hides clearly identifiable unavailable/sold-out rows. Never hides
// rows whose availability status is merely unknown or still loading.

(function () {
  const NS = window.TMnoBS;
  const REASON = "soldout";

  const ROW_SELECTORS = [
    '[data-testid*="listing" i]',
    '[data-testid*="offer" i]',
    '[class*="quick-pick" i]',
    '[class*="listing" i]',
    '[class*="ticket-group" i]'
  ];

  const SOLD_OUT_PATTERNS = ["sold out", "unavailable", "no longer available", "not available"];
  const LOADING_PATTERNS = ["loading", "checking availability", "please wait"];

  function collectRows() {
    const seen = new Set();
    const rows = [];
    ROW_SELECTORS.forEach((sel) => {
      let nodes;
      try {
        nodes = document.querySelectorAll(sel);
      } catch (e) {
        return;
      }
      nodes.forEach((el) => {
        if (!seen.has(el)) {
          seen.add(el);
          rows.push(el);
        }
      });
    });
    return rows;
  }

  function run(settings) {
    if (!settings.hideSoldOut) {
      NS.tmUnhideByReason(REASON);
      return;
    }

    collectRows().forEach((row) => {
      const text = NS.normText(row);
      if (!text) return;
      if (LOADING_PATTERNS.some((p) => text.includes(p))) return; // status unknown, leave visible
      if (SOLD_OUT_PATTERNS.some((p) => text.includes(p))) {
        // Also require a disabled-looking control, for extra confidence.
        const disabledControl = row.querySelector('[disabled], [aria-disabled="true"]');
        if (disabledControl || row.matches('[class*="disabled" i], [class*="unavailable" i]')) {
          NS.tmHide(row, REASON);
        } else {
          NS.tmHide(row, REASON); // text match alone is still a strong signal
        }
      }
    });
  }

  NS.features.soldOut = { run };
})();
