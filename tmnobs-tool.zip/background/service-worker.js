// TMnoBS background service worker
// Seeds default settings on install, and toggles the on-page floating
// panel when the toolbar icon is clicked. All actual page interaction
// still happens only in content scripts.

const DEFAULT_SETTINGS = {
  power: false,
  panelOpen: false,
  panelX: null,
  panelY: null,
  noStartupNotices: false,
  noOfferReminders: false,
  hideVerifiedResale: false,
  hideVip: false,
  hideOfficialPlatinum: false,
  hideMeetGreet: false,
  hideCitiPreferred: false,
  keepOfferTickets: true,
  ticketQuantity: 2,
  hideTcReminder: false,
  skipAccessibilityAgreements: false,
  noTicketProtection: false,
  rememberCheckoutPreferences: false,
  rememberFilters: false,
  hideAbovePrice: false,
  maxPrice: 0,
  hideSoldOut: false,
  rememberMapView: false,
  quietMode: false,
  magicSelector: false
};

chrome.runtime.onInstalled.addListener(async (details) => {
  if (details.reason === "install") {
    await chrome.storage.local.set({ tmnobsSettings: DEFAULT_SETTINGS });
  } else if (details.reason === "update") {
    const stored = await chrome.storage.local.get("tmnobsSettings");
    const current = stored.tmnobsSettings || {};
    const merged = { ...DEFAULT_SETTINGS, ...current };
    await chrome.storage.local.set({ tmnobsSettings: merged });
  }
});

// Clicking the toolbar icon toggles the floating in-page panel on the
// current tab (the content script listens for this setting to change).
chrome.action.onClicked.addListener(async (tab) => {
  const stored = await chrome.storage.local.get("tmnobsSettings");
  const settings = { ...DEFAULT_SETTINGS, ...(stored.tmnobsSettings || {}) };
  settings.panelOpen = !settings.panelOpen;
  await chrome.storage.local.set({ tmnobsSettings: settings });
});
